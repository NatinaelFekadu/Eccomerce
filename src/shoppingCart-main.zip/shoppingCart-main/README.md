# shoppingCart

Some screenshots from the projects

![Screenshot (145)](https://user-images.githubusercontent.com/68517660/138469639-19e490cf-38e6-4d3a-82cb-ea8f9cdda3e6.png)


                       


![Screenshot (146)](https://user-images.githubusercontent.com/68517660/138469665-7a52af52-a0d6-4084-8b05-2e449f76ea15.png)
